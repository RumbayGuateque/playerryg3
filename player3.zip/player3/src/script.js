const audioPlayer = document.getElementById("audioPlayer");
const playPauseBtn = document.getElementById("playPauseBtn");
const playText = document.getElementById("playText");

// Alternar reproducción y pausa
function togglePlay() {
    if (audioPlayer.paused) {
        audioPlayer.play();
        playText.innerText = "PAUSE"; // Cambiar texto a "PAUSE"
    } else {
        audioPlayer.pause();
        playText.innerText = "PLAY"; // Cambiar texto a "PLAY"
    }
}

// Ajustar el nivel de volumen
function setVolume(value) {
    audioPlayer.volume = value;
}
